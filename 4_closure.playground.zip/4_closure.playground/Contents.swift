import UIKit

let scores = [80, 90, 75, 99]

let sortedScores = scores.sorted()
sortedScores



